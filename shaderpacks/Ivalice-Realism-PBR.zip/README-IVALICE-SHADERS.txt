========================================================================
IVALICE REALISM PBR SHADERPACK (v1.3)
Projeto Ivalice - Final Fantasy XII Minecraft 26.3 NeoForge
========================================================================

FEATURES:
1. Full LabPBR 1.3 Material Standard Support:
   - Normal Maps (_n.png):
     * R: Tangent Normal X
     * G: Tangent Normal Y
     * B: Cavity / Ambient Occlusion
     * A: Heightmap for Parallax Occlusion Mapping (POM)
   - Specular Maps (_s.png):
     * R: Perceptual Smoothness (Roughness = 1.0 - Smoothness)
     * G: F0 Reflectance / Metallic (> 225 indicates metallic conductive surface)
     * B: Porosity / Subsurface Scattering
     * A: Emissive veins (Amber lantern, Sunstone ore, Feywood runes, Scorched magma)

2. Atmosphere & Aesthetics:
   - Warm Dalmascan Solar Tone Mapping: Inspired by FFXII's golden desert sunlight.
   - Micro-relief depth and crisp surface specular reflections on marble, steel, gold, and rime ice.
   - Atmospheric regional haze/mist.

3. Compatibility:
   - Iris Shaders on NeoForge 26.3.
   - Parallax is off by default. Enable it in Shader Pack Settings.

INSTALLATION:
Place 'Ivalice-Realism-PBR.zip' into your '.minecraft/shaderpacks' directory
and activate it via Iris Video Settings -> Shader Packs.
