#version 120

/*
 * Ivalice Realism PBR - Final Fragment Shader
 * Subtle filmic vignette and output to display
 */

uniform sampler2D colortex0;

varying vec2 texcoord;

void main() {
    vec4 color = texture2D(colortex0, texcoord);

    vec2 coord = (texcoord - 0.5) * 2.0;
    float vignette = 1.0 - dot(coord, coord) * 0.045;
    color.rgb *= clamp(vignette, 0.0, 1.0);

    gl_FragColor = color;
}
