#version 120

/*
 * Ivalice Realism PBR - Entities / Hand / Armor Vertex Shader
 * Enhances 3D GeckoLib entities and held items with directional rim lighting and specular sheen.
 */

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;
varying vec3 viewVector;
varying vec3 lightVector;

uniform vec3 sunPosition;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    color = gl_Color;

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    viewVector = -viewPos.xyz;
    normal = normalize(gl_NormalMatrix * gl_Normal);

    lightVector = normalize(sunPosition);
    if (length(lightVector) < 0.1) {
        lightVector = normalize(vec3(0.3, 0.8, 0.5));
    }

    gl_Position = ftransform();
}
