#version 130

/*
 * Ivalice Realism PBR - Terrain Fragment Shader
 * LabPBR 1.3: _n.png (R/G normal, B AO, A height) + _s.png (R smooth, G F0, A emissive)
 * The parallax ray is confined to the original quad's atlas footprint. Coverage is
 * always read from the original atlas UV, including cutouts and vegetation.
 */

uniform sampler2D gtexture;
uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D lightmap;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;
varying vec3 viewVector;
varying vec3 lightVector;
varying mat3 tbnMatrix;
varying vec4 tileBounds;
varying vec2 localCoord;

#define IVALICE_PARALLAX 0 // [0 1]
#define POM_DEPTH 0.06 // [0.03 0.06 0.09]

/* DRAWBUFFERS:0 */

#if IVALICE_PARALLAX == 1
vec2 toAtlas(vec2 local, vec2 inset) {
    return tileBounds.xy + clamp(local, inset, 1.0 - inset) * tileBounds.zw;
}

float heightAt(vec2 local, vec2 inset, vec2 uvDx, vec2 uvDy) {
    return textureGrad(normals, toAtlas(local, inset), uvDx, uvDy).a;
}

vec2 parallaxLocal(vec2 local, vec3 viewTS, float fade, vec2 inset, vec2 uvDx, vec2 uvDy) {
    const int steps = 12;
    float layer = 1.0 / float(steps);
    vec2 delta = -viewTS.xy / max(viewTS.z, 0.35) * POM_DEPTH * fade * layer;

    float depth = 0.0;
    float surface = 1.0 - heightAt(local, inset, uvDx, uvDy);
    vec2 previous = local;
    float previousGap = 0.0;
    for (int i = 0; i < steps; i++) {
        if (depth >= surface) break;
        previous = local;
        previousGap = surface - depth;
        local += delta;
        depth += layer;
        surface = 1.0 - heightAt(local, inset, uvDx, uvDy);
    }
    float overshoot = max(0.0, depth - surface);
    float blend = overshoot / max(overshoot + previousGap, 1.0e-4);
    return mix(local, previous, blend);
}
#endif

void main() {
    vec4 baseColor = texture2D(gtexture, texcoord);
    float coverage = baseColor.a * color.a;
    if (coverage < 0.1) discard;

    vec4 nSample = texture2D(normals, texcoord);
    vec4 sSample = texture2D(specular, texcoord);
    vec3 V = normalize(viewVector);
    vec3 L = normalize(lightVector);

    #if IVALICE_PARALLAX == 1
    vec2 uvDx = dFdx(texcoord);
    vec2 uvDy = dFdy(texcoord);
    vec2 atlasPixels = vec2(textureSize(gtexture, 0));
    vec2 quadPixels = tileBounds.zw * atlasPixels;
    vec4 drift = (abs(dFdx(tileBounds)) + abs(dFdy(tileBounds))) * atlasPixels.xyxy;
    vec2 edge = min(localCoord, 1.0 - localCoord);
    vec3 viewTS = normalize(V * tbnMatrix);
    float fade = (1.0 - smoothstep(12.0, 20.0, length(viewVector))) *
                 smoothstep(0.04, 0.16, min(edge.x, edge.y)) *
                 smoothstep(0.35, 0.60, viewTS.z);
    if (fade > 0.0 && coverage > 0.99 && nSample.a < 0.995 &&
            min(quadPixels.x, quadPixels.y) >= 8.0 &&
            max(max(drift.x, drift.y), max(drift.z, drift.w)) < 0.10) {
        vec2 mipFootprint = max(abs(uvDx), abs(uvDy)) * atlasPixels;
        vec2 inset = clamp((0.5 + mipFootprint) / quadPixels, vec2(0.02), vec2(0.4));
        vec2 local = parallaxLocal(localCoord, viewTS, fade, inset, uvDx, uvDy);
        vec2 uv = toAtlas(local, inset);
        vec4 displaced = textureGrad(gtexture, uv, uvDx, uvDy);
        if (displaced.a > 0.99) {
            baseColor.rgb = displaced.rgb;
            nSample = textureGrad(normals, uv, uvDx, uvDy);
            sSample = textureGrad(specular, uv, uvDx, uvDy);
        }
    }
    #endif

    vec4 albedo = vec4(baseColor.rgb * color.rgb, coverage);
    vec3 N = normalize(normal);
    vec2 normalXY = nSample.rg * 2.0 - 1.0;
    if (length(normalXY) > 0.012) {
        vec3 nTS = vec3(normalXY, sqrt(max(0.0, 1.0 - dot(normalXY, normalXY))));
        N = normalize(tbnMatrix * nTS);
    }
    float ao = clamp(nSample.b, 0.35, 1.0);
    float smoothness = sSample.r;
    float f0 = sSample.g;
    float emissive = sSample.a < 0.999 ? sSample.a : 0.0;

    vec4 lm = texture2D(lightmap, lmcoord);
    float NdotL = max(0.0, dot(N, L));
    vec3 H = normalize(L + V);
    float roughness = max(0.05, 1.0 - smoothness);
    float spec = pow(max(0.0, dot(N, H)), min(2.0 / (roughness * roughness), 256.0)) * smoothness * 0.6;

    vec3 specColor = vec3(1.0);
    if (f0 > 0.88) {
        specColor = albedo.rgb;
        albedo.rgb *= 0.35 + 0.65 * (1.0 - smoothness);
    }

    // Keep vanilla brightness as baseline (lightmap), add directional relief on top.
    float relief = mix(0.82, 1.12, NdotL);
    vec3 finalColor = albedo.rgb * lm.rgb * relief * mix(0.85, 1.0, ao);
    finalColor += spec * specColor * lm.rgb;
    if (emissive > 0.25) finalColor += albedo.rgb * emissive * 1.6;

    gl_FragData[0] = vec4(finalColor, albedo.a);
}
