#version 120

/*
 * Ivalice Realism PBR - Terrain Fragment Shader
 * Full LabPBR 1.3 specification:
 * - Normal map (_n.png): R=nx, G=ny, B=AO, A=height
 * - Specular map (_s.png): R=smoothness, G=F0/metalness, B=porosity, A=emissive
 * - Parallax Occlusion Mapping (POM)
 */

uniform sampler2D texture;
uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D lightmap;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;
varying vec3 viewVector;
varying vec3 lightVector;
varying mat3 tbnMatrix;

/* DRAWBUFFERS:0 */

vec2 getParallaxCoord(vec2 uv, vec3 viewDirTS, out float outHeight) {
    float depthScale = 0.095;
    const int numSteps = 12;
    float stepSize = 1.0 / float(numSteps);
    vec2 deltaUV = -viewDirTS.xy * depthScale * stepSize / max(viewDirTS.z, 0.12);

    vec2 currUV = uv;
    vec2 prevUV = uv;
    float currLayerDepth = 0.0;
    float prevLayerDepth = 0.0;
    float currHeight = 1.0 - texture2D(normals, currUV).a;
    float prevHeight = currHeight;

    for (int i = 0; i < numSteps; i++) {
        if (currLayerDepth >= currHeight) {
            float afterDepth = currHeight - currLayerDepth;
            float beforeDepth = prevHeight - prevLayerDepth;
            float weight = afterDepth / (afterDepth - beforeDepth + 0.0001);
            vec2 finalUV = mix(currUV, prevUV, weight);
            outHeight = 1.0 - mix(currLayerDepth, prevLayerDepth, weight);
            return finalUV;
        }
        prevUV = currUV;
        prevHeight = currHeight;
        prevLayerDepth = currLayerDepth;

        currUV += deltaUV;
        currHeight = 1.0 - texture2D(normals, currUV).a;
        currLayerDepth += stepSize;
    }
    outHeight = 1.0 - currLayerDepth;
    return currUV;
}

float computePomShadow(vec2 pcoord, vec3 lightDirTS, float pHeight) {
    if (lightDirTS.z <= 0.0) return 0.25;
    float depthScale = 0.095;
    const int shadowSteps = 6;
    float stepSize = 1.0 / float(shadowSteps);
    vec2 deltaUV = lightDirTS.xy * depthScale * stepSize / max(lightDirTS.z, 0.15);

    float currentLayerDepth = 1.0 - pHeight;
    vec2 currUV = pcoord;
    float shadow = 1.0;

    for (int i = 0; i < shadowSteps; i++) {
        currUV += deltaUV;
        currentLayerDepth -= stepSize;
        if (currentLayerDepth <= 0.0) break;
        float hSample = 1.0 - texture2D(normals, currUV).a;
        if (hSample < currentLayerDepth - 0.03) {
            shadow -= (1.0 - float(i) / float(shadowSteps)) * 0.45;
            break;
        }
    }
    return clamp(shadow, 0.25, 1.0);
}

void main() {
    vec3 V = normalize(viewVector);
    vec3 viewDirTS = normalize(V * tbnMatrix);
    vec2 pcoord = texcoord;
    float pHeight = 1.0;

    vec4 nMapRaw = texture2D(normals, texcoord);
    if (nMapRaw.a > 0.01 && nMapRaw.a < 0.99) {
        pcoord = getParallaxCoord(texcoord, viewDirTS, pHeight);
    } else {
        pHeight = nMapRaw.a;
    }

    vec4 albedo = texture2D(texture, pcoord) * color;
    if (albedo.a < 0.1) {
        discard;
    }

    // Normal & AO from LabPBR _n.png
    vec4 nSample = texture2D(normals, pcoord);
    vec3 N = normal;
    if (length(nSample.rgb) > 0.05) {
        vec3 normalTS = nSample.xyz * 2.0 - 1.0;
        normalTS.xy *= 2.2;
        N = normalize(tbnMatrix * normalize(normalTS));
    }
    float ao = clamp(nSample.b, 0.2, 1.0);

    // Light vectors & Parallax Self-Shadowing
    vec3 L = normalize(lightVector);
    vec3 lightDirTS = normalize(L * tbnMatrix);
    float pomShadow = computePomShadow(pcoord, lightDirTS, pHeight);

    // Specular & Emission from LabPBR _s.png
    vec4 sSample = texture2D(specular, pcoord);
    float smoothness = sSample.r;
    float f0_metal = sSample.g;
    float emissiveRaw = sSample.a;

    vec3 H = normalize(L + V);
    float NdotL = max(0.0, dot(N, L));
    vec4 lm = texture2D(lightmap, lmcoord);
    vec3 ambient = lm.rgb * (0.60 + 0.40 * ao);

    // Crisp microfacet Blinn-Phong specular highlight
    float roughness = max(0.03, 1.0 - smoothness);
    float specPower = 2.0 / (roughness * roughness + 0.0005);
    float NdotH = max(0.0, dot(N, H));
    float specHighlight = pow(NdotH, min(specPower, 512.0)) * smoothness;

    vec3 specColor = vec3(1.0);
    if (f0_metal > 0.88) { // Metallic (> 225 LabPBR)
        specColor = mix(vec3(1.0), albedo.rgb, 0.90);
        albedo.rgb *= 0.12 + 0.88 * (1.0 - smoothness);
    }

    vec3 directLight = vec3(1.20, 1.08, 0.95) * (NdotL * pomShadow * 0.80 + 0.20);
    vec3 finalColor = albedo.rgb * (ambient * 0.65 + directLight * 0.70) + specHighlight * specColor * directLight * pomShadow;

    // Glowing veins / runes / magma emission boost
    if (emissiveRaw > 0.6) {
        vec3 glowColor = albedo.rgb * (2.8 * emissiveRaw);
        finalColor += glowColor;
    }

    gl_FragData[0] = vec4(finalColor, albedo.a);
}
