#version 120

/*
 * Ivalice Realism PBR - Terrain Fragment Shader
 * LabPBR 1.3: _n.png (R/G normal, B AO, A height) + _s.png (R smooth, G F0, A emissive)
 * Parallax Occlusion Mapping is computed in sprite-local space and wrapped inside the
 * atlas tile, so it can never leak into other sprites (fixes the "grid / see-through" bug).
 */

uniform sampler2D texture;
uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D lightmap;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;
varying vec3 viewVector;
varying vec3 lightVector;
varying mat3 tbnMatrix;
varying vec4 tileBounds;
varying vec2 localCoord;

#define POM_DEPTH 0.18
#define POM_DISTANCE 24.0

/* DRAWBUFFERS:0 */

vec2 toAtlas(vec2 local) {
    return tileBounds.xy + fract(local) * tileBounds.zw;
}

float heightAt(vec2 local) {
    return texture2D(normals, toAtlas(local)).a;
}

vec2 parallaxLocal(vec2 local, vec3 viewTS, out float outHeight) {
    const int steps = 12;
    float layer = 1.0 / float(steps);
    vec2 delta = -viewTS.xy / max(viewTS.z, 0.25) * POM_DEPTH * layer;

    float depth = 0.0;
    float h = 1.0 - heightAt(local);
    vec2 prevLocal = local;
    float prevH = h;
    for (int i = 0; i < steps; i++) {
        if (depth >= h) break;
        prevLocal = local;
        prevH = h;
        local += delta;
        depth += layer;
        h = 1.0 - heightAt(local);
    }
    float after = h - depth;
    float before = prevH - (depth - layer);
    float w = clamp(after / (after - before + 1.0e-4), 0.0, 1.0);
    outHeight = 1.0 - (depth - w * layer);
    return mix(local, prevLocal, w);
}

float pomShadow(vec2 local, vec3 lightTS, float h0) {
    if (lightTS.z <= 0.0) return 0.55;
    const int steps = 6;
    vec2 delta = lightTS.xy / max(lightTS.z, 0.3) * POM_DEPTH / float(steps);
    float shadow = 1.0;
    for (int i = 1; i <= steps; i++) {
        float rayH = h0 + float(i) / float(steps) * (1.0 - h0);
        if (heightAt(local + delta * float(i)) > rayH + 0.04) {
            shadow = 0.6;
            break;
        }
    }
    return shadow;
}

void main() {
    vec3 V = normalize(viewVector);
    vec3 viewTS = normalize(V * tbnMatrix);

    vec2 local = localCoord;
    float pHeight = 1.0;
    bool usePom = false;

    vec4 nRaw = texture2D(normals, texcoord);
    float dist = length(viewVector);
    if (dist < POM_DISTANCE && nRaw.a > 0.02 && nRaw.a < 0.98) {
        local = parallaxLocal(localCoord, viewTS, pHeight);
        usePom = true;
    }

    // Only remap the atlas lookup when POM actually moved the coordinate;
    // otherwise keep the hardware-filtered original texcoord (no seams, no mip issues).
    vec2 uv = usePom ? toAtlas(local) : texcoord;

    vec4 albedo = texture2D(texture, uv) * color;
    if (albedo.a < 0.1) discard;

    vec4 nSample = usePom ? texture2D(normals, uv) : nRaw;
    vec3 N = normal;
    // Vanilla blocks without a _n.png get Iris' flat default; only apply real maps.
    if (nSample.a > 0.0 && abs(nSample.r - 0.5) + abs(nSample.g - 0.5) > 0.004) {
        vec3 nTS = vec3(nSample.rg * 2.0 - 1.0, 0.0);
        nTS.xy *= 1.4;
        nTS.z = sqrt(max(0.0, 1.0 - dot(nTS.xy, nTS.xy)));
        N = normalize(tbnMatrix * normalize(nTS));
    }
    float ao = clamp(nSample.b, 0.35, 1.0);

    vec3 L = normalize(lightVector);
    float shadow = usePom ? pomShadow(local, normalize(L * tbnMatrix), pHeight) : 1.0;

    vec4 sSample = texture2D(specular, uv);
    float smoothness = sSample.r;
    float f0 = sSample.g;
    float emissive = sSample.a < 0.999 ? sSample.a : 0.0;

    vec4 lm = texture2D(lightmap, lmcoord);
    float NdotL = max(0.0, dot(N, L));
    vec3 H = normalize(L + V);
    float roughness = max(0.05, 1.0 - smoothness);
    float spec = pow(max(0.0, dot(N, H)), min(2.0 / (roughness * roughness), 256.0)) * smoothness * 0.6;

    vec3 specColor = vec3(1.0);
    if (f0 > 0.88) {
        specColor = albedo.rgb;
        albedo.rgb *= 0.35 + 0.65 * (1.0 - smoothness);
    }

    // Keep vanilla brightness as baseline (lightmap), add directional relief on top.
    float sky = lm.b > 0.0 ? 1.0 : 1.0;
    float relief = mix(0.82, 1.12, NdotL) * shadow;
    vec3 finalColor = albedo.rgb * lm.rgb * relief * mix(0.85, 1.0, ao);
    finalColor += spec * specColor * lm.rgb * shadow;
    if (emissive > 0.25) finalColor += albedo.rgb * emissive * 1.6;

    gl_FragData[0] = vec4(finalColor * sky, albedo.a);
}
