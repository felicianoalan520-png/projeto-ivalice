#version 120
varying vec4 skyTint;
varying vec3 skyDirection;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform int renderStage;

/* DRAWBUFFERS:0 */

void main() {
    if (renderStage == MC_RENDER_STAGE_SKY || renderStage == MC_RENDER_STAGE_VOID) {
        float elevation = normalize(skyDirection).y;
        float height = smoothstep(-0.06, 0.42, elevation);
        vec3 upperSky = max(skyColor, fogColor * 0.35);
        gl_FragData[0] = vec4(mix(fogColor, upperSky, height), 1.0);
    } else {
        gl_FragData[0] = skyTint;
    }
}
