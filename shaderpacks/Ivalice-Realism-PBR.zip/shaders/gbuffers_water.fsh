#version 120

/*
 * Ivalice Realism PBR - Translucent / Water / Stained Glass Fragment Shader
 * Adds Fresnel reflections and solar specular glints on water and Archadian stained glass.
 */

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec3 fogColor;
uniform float sunAngle;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;
varying vec3 viewVector;
varying vec3 lightVector;
varying float waterBlock;

/* DRAWBUFFERS:0 */

void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    if (albedo.a < 0.05) {
        discard;
    }

    vec3 N = normalize(normal);
    vec3 V = normalize(viewVector);
    vec3 L = normalize(lightVector);
    vec3 H = normalize(L + V);

    float NdotV = max(0.0, dot(N, V));
    float fresnel = pow(1.0 - NdotV, 4.0) * 0.45;
    float sunSpec = pow(max(0.0, dot(N, H)), 48.0) * 0.15 * smoothstep(0.6, 0.97, lmcoord.y);

    vec4 lm = texture2D(lightmap, lmcoord);
    vec3 finalRgb = albedo.rgb * lm.rgb + vec3(1.25, 1.15, 0.98) * (sunSpec + fresnel * 0.35);
    float finalAlpha = clamp(albedo.a + fresnel * 0.36 + sunSpec * 0.2, 0.0, 1.0);
    if (waterBlock > 0.5) {
        float daylight = smoothstep(0.0, 0.08, sunAngle) * (1.0 - smoothstep(0.42, 0.50, sunAngle));
        vec3 waterTint = mix(color.rgb * vec3(0.53, 0.67, 0.79), albedo.rgb, 0.32);
        finalRgb = mix(waterTint * lm.rgb, fogColor, fresnel * 0.56);
        finalRgb += vec3(1.0, 0.94, 0.81) * sunSpec * daylight * 0.65;
        finalAlpha = clamp(max(0.42, albedo.a) + fresnel * 0.69, 0.0, 0.90);
    }

    gl_FragData[0] = vec4(finalRgb, finalAlpha);
}
