#version 120

/*
 * Ivalice Realism PBR - Entities / Hand / Armor Fragment Shader
 * Adds directional shading, rim light, and crisp specular highlights to 3D GeckoLib creatures & weapons.
 */

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec4 entityColor;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;
varying vec3 viewVector;
varying vec3 lightVector;

/* DRAWBUFFERS:0 */

void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    if (albedo.a < 0.1) {
        discard;
    }
    albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);

    vec3 N = normalize(normal);
    vec3 V = normalize(viewVector);
    vec3 L = normalize(lightVector);
    vec3 H = normalize(L + V);

    float NdotL = max(0.0, dot(N, L));
    float NdotV = max(0.0, dot(N, V));
    float rim = pow(1.0 - NdotV, 3.2) * 0.28;
    float spec = pow(max(0.0, dot(N, H)), 36.0) * 0.22;

    vec4 lm = texture2D(lightmap, lmcoord);
    vec3 lighting = lm.rgb * (0.58 + 0.48 * NdotL) + vec3(1.15, 1.04, 0.90) * (spec + rim);

    gl_FragData[0] = vec4(albedo.rgb * lighting, albedo.a);
}
