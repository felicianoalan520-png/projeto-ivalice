#version 120

/*
 * Ivalice Realism PBR - Composite Fragment Shader
 * Warm Dalmascan Golden Tone Mapping & Subtle Atmospheric Mist
 */

uniform sampler2D colortex0;
uniform sampler2D depthtex0;

varying vec2 texcoord;

/* DRAWBUFFERS:0 */

float linearizeDepth(float depth) {
    float near = 0.1;
    float far = 256.0;
    return (2.0 * near) / (far + near - depth * (far - near));
}

void main() {
    vec4 scene = texture2D(colortex0, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;
    float linDepth = linearizeDepth(depth);

    vec3 color = scene.rgb;

    // Warm Ivalice tone mapping (Dalmasca golden sunlight)
    vec3 warmColor = color * vec3(1.05, 1.01, 0.96);
    color = (warmColor * (2.51 * warmColor + 0.03)) / (warmColor * (2.43 * warmColor + 0.59) + 0.14);

    // Subtle atmospheric mist
    if (depth < 1.0) {
        float mistFactor = 1.0 - exp(-linDepth * 18.0 * 0.0035);
        mistFactor = clamp(mistFactor, 0.0, 0.45);
        vec3 mistColor = vec3(0.85, 0.80, 0.72);
        color = mix(color, mistColor, mistFactor);
    }

    gl_FragData[0] = vec4(color, scene.a);
}
