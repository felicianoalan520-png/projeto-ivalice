#version 120

/*
 * Ivalice Realism PBR - Composite Fragment Shader
 * Warm Dalmascan Golden Tone Mapping & Subtle Atmospheric Mist
 */

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform vec3 fogColor;
uniform float fogStart;
uniform float fogEnd;
uniform float far;
uniform int fogShape;
uniform int isEyeInWater;

varying vec2 texcoord;

/* DRAWBUFFERS:0 */

void main() {
    vec4 scene = texture2D(colortex0, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;
    vec3 color = scene.rgb;

    if (depth < 0.999999) {
        vec4 projected = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
        vec3 view = projected.xyz / max(0.00001, abs(projected.w));
        float distance = fogShape == 1 ? max(length(view.xz), abs(view.y)) : length(view);
        float endDistance = fogEnd > 1.0 ? fogEnd : far;
        float startDistance = isEyeInWater == 0 ? min(fogStart, endDistance * 0.68) : fogStart;
        float fog = smoothstep(max(0.0, startDistance), max(startDistance + 1.0, endDistance), distance);
        color = mix(color, fogColor, fog);
    }

    // A restrained grade keeps night and dusk from crushing to black.
    color = clamp(color * vec3(1.035, 1.005, 0.98), 0.0, 1.0);
    gl_FragData[0] = vec4(color, scene.a);
}
