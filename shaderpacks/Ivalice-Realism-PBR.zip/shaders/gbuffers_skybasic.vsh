#version 120
varying vec4 skyTint;
varying vec3 skyDirection;
uniform mat4 gbufferModelViewInverse;

void main() {
    skyTint = gl_Color;
    skyDirection = mat3(gbufferModelViewInverse) * (gl_ModelViewMatrix * gl_Vertex).xyz;
    gl_Position = ftransform();
}
