#version 120

/*
 * Ivalice Realism PBR - Terrain Vertex Shader
 * Computes view-space TBN, light vector and the atlas tile bounds (mc_midTexCoord)
 * so Parallax Occlusion Mapping never samples neighbouring atlas sprites.
 */

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;
varying vec3 viewVector;
varying vec3 lightVector;
varying mat3 tbnMatrix;
varying vec4 tileBounds;   // xy = tile origin in atlas, zw = tile size in atlas
varying vec2 localCoord;   // 0..1 inside the sprite

attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

uniform vec3 sunPosition;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    color = gl_Color;

    vec2 midCoord = (gl_TextureMatrix[0] * vec4(mc_midTexCoord.xy, 0.0, 1.0)).xy;
    vec2 halfSize = texcoord - midCoord;
    tileBounds.zw = max(abs(halfSize) * 2.0, vec2(1.0e-6));
    tileBounds.xy = min(texcoord, midCoord - halfSize);
    localCoord = sign(halfSize) * 0.5 + 0.5;

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    viewVector = -viewPos.xyz;

    vec3 n = normalize(gl_NormalMatrix * gl_Normal);
    vec3 t;
    if (length(at_tangent.xyz) > 0.01) {
        t = normalize(gl_NormalMatrix * at_tangent.xyz);
    } else {
        t = normalize(abs(n.y) < 0.99 ? cross(n, vec3(0.0, 1.0, 0.0)) : cross(n, vec3(1.0, 0.0, 0.0)));
    }
    vec3 b = cross(t, n) * (at_tangent.w < 0.0 ? -1.0 : 1.0);
    tbnMatrix = mat3(t, b, n);
    normal = n;

    lightVector = normalize(sunPosition);
    if (length(sunPosition) < 0.1) {
        lightVector = normalize(vec3(0.3, 0.8, 0.5));
    }

    gl_Position = ftransform();
}
