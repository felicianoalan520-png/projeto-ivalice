#version 120
uniform sampler2D gtexture;
varying vec4 skyTint;
varying vec2 uv;
/* DRAWBUFFERS:0 */
void main() {
    gl_FragData[0] = texture2D(gtexture, uv) * skyTint;
}
