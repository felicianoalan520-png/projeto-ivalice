#version 120
varying vec4 skyTint;
varying vec2 uv;
void main() {
    skyTint = gl_Color;
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}
